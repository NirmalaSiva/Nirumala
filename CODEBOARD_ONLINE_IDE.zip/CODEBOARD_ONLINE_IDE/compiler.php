<?php
// ini_set('display_errors',0);
// ini_set('log_errors',1);
$language = strtolower($_POST['language']);
$code = $_POST['code'];

$random = substr(md5(mt_rand()), 0,7);
$t=time();
$filePath = "temp/" . $random . "_" . $language."_".$t.".txt";

$programFile = fopen($filePath, "w");

//fwrite($filePath,$code);
if(!file_put_contents($filePath, $code )) die ("can not write to file");

//echo $filePath;
//exit;
fclose($programFile);

//$absolute_path = $_SERVER['DOCUMENT_ROOT'];
//echo $absolute_path;
//exit;
// if (!file_exists($absolute_path."/Nirmal_workspace/CODEBOARD_ONLINE_IDE/temp/path/file.txt")) { 
//     die('File does not exist');
// }

// clearstatcache();

// $fh = fopen($absolute_path."/Nirmal_workspace/CODEBOARD_ONLINE_IDE/temp/path/file.txt", "r") or die("can't open file");
// $sql = fread($fh,filesize($absolute_path."/Nirmal_workspace/CODEBOARD_ONLINE_IDE/temp/path/file.txt"));
